'use strict';
/**
 * @ngdoc overview
 * @name shellApp
 * @description
 * # shellApp
 *
 * Main module of the application.
 */
angular
  .module('shellApp', [
    'oc.lazyLoad',
    'ui.router',
    'ui.bootstrap',
    'angular-loading-bar',
  ])
  .config(['$stateProvider','$urlRouterProvider','$ocLazyLoadProvider',function ($stateProvider,$urlRouterProvider,$ocLazyLoadProvider) {
    
    $ocLazyLoadProvider.config({
      debug:false,
      events:true,
    });

    $urlRouterProvider.otherwise('/dashboard/home');

    $stateProvider
      .state('dashboard', {
        url:'/dashboard',
        templateUrl: 'app/dashboard/main.html',
        resolve: {
            loadMyDirectives:function($ocLazyLoad){
                return $ocLazyLoad.load(
                {
                    name:'shellApp',
                    files:[
                    'app/components/header/header.directive.js',
                    'app/components/header/sub-header/sub-header.directive.js',
                    'app/components/header/header-notification/header-notification.directive.js',
                    'app/components/sidebar/sidebar.directive.js',
                    'app/components/sidebar/sidebar-search/sidebar-search.directive.js'
                    ]
                }),
                $ocLazyLoad.load(
                {
                   name:'toggle-switch',
                   files:["node_modules/angular-toggle-switch/angular-toggle-switch.min.js",
                          "node_modules/angular-toggle-switch/angular-toggle-switch.css"
                      ]
                }),
                $ocLazyLoad.load(
                {
                  name:'ngAnimate',
                  files:['node_modules/angular-animate/angular-animate.js']
                })
                $ocLazyLoad.load(
                {
                  name:'ngCookies',
                  files:['node_modules/angular-cookies/angular-cookies.js']
                })
                $ocLazyLoad.load(
                {
                  name:'ngResource',
                  files:['node_modules/angular-resource/angular-resource.js']
                })
                $ocLazyLoad.load(
                {
                  name:'ngSanitize',
                  files:['node_modules/angular-sanitize/angular-sanitize.js']
                })
                $ocLazyLoad.load(
                {
                  name:'ngTouch',
                  files:['node_modules/angular-touch/angular-touch.js']
                })
            }
        }
    })
      .state('dashboard.home',{
        url:'/home',
        controller: 'MainController',
        templateUrl:'app/dashboard/home.html',
        resolve: {
          loadMyFiles:function($ocLazyLoad) {
            return $ocLazyLoad.load({
              name:'shellApp',
              files:[
              'app/dashboard/main.controller.js',
              'app/components/timeline/timeline.directive.js',
              'app/components/notifications/notifications.directive.js',
              'app/components/chat/chat.directive.js',
              'app/components/dashboard/stats/stats.directive.js'
              ]
            })
          }
        }
      })
      .state('dashboard.form',{
        templateUrl:'app/form/form.html',
        url:'/form'
    })
      .state('dashboard.blank',{
        templateUrl:'app/pages/blank.html',
        url:'/blank'
    })
      .state('login',{
        templateUrl:'app/pages/login.html',
        url:'/login'
    })
      .state('dashboard.chart',{
        templateUrl:'app/chart/chart.html',
        url:'/chart',
        controller:'ChartController',
        resolve: {
          loadMyFile:function($ocLazyLoad) {
            return $ocLazyLoad.load({
              name:'chart.js',
              files:[
                'node_modules/angular-chart.js/dist/angular-chart.min.js',
                'node_modules/angular-chart.js/dist/angular-chart.css'
              ]
            }),
            $ocLazyLoad.load({
                name:'shellApp',
                files:['app/chart/chart.contoller.js']
            })
          }
        }
    })
      .state('dashboard.table',{
          templateUrl: 'app/ui-elements/table.html',
        url:'/table'
    })
      .state('dashboard.panels-wells',{
          templateUrl:'app/ui-elements/panels-wells.html',
          url:'/panels-wells'
      })
      .state('dashboard.buttons',{
        templateUrl:'app/ui-elements/buttons.html',
        url:'/buttons'
    })
      .state('dashboard.notifications',{
        templateUrl:'app/ui-elements/notifications.html',
        url:'/notifications'
    })
      .state('dashboard.typography',{
       templateUrl:'app/ui-elements/typography.html',
       url:'/typography'
   })
      .state('dashboard.icons',{
       templateUrl:'app/ui-elements/icons.html',
       url:'/icons'
   })
      .state('dashboard.grid',{
       templateUrl:'app/ui-elements/grid.html',
       url:'/grid'
   })
  }]);

    
