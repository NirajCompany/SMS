'use strict';
/**
 * @ngdoc function
 * @name shellApp.controller:MainController
 * @description
 * # MainController
 * Controller of the shellApp
 */
angular.module('shellApp')
  .controller('MainController', function($scope,$position) {
  });
