'use strict';

/**
 * @ngdoc directive
 * @name izzyposWebApp.directive:adminPosHeader
 * @description
 * # adminPosHeader
 */
angular.module('shellApp')
	.directive('chat',function(){
		return {
		    templateUrl: 'app/components/chat/chat.html',
        restrict: 'E',
        replace: true,
    	}
	});


