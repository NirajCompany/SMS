'use strict';

/**
 * @ngdoc directive
 * @name izzyposWebApp.directive:adminPosHeader
 * @description
 * # adminPosHeader
 */
angular.module('shellApp')
	.directive('subHeader',function(){
		return {
		    templateUrl: 'app/components/header/sub-header/sub-header.html',
        restrict: 'E',
        replace: true,
    	}
	});


