'use strict';
/**
 * @ngdoc function
 * @name shellApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the shellApp
 */
angular.module('shellApp')
  .controller('FormController', function($scope) {
    
});